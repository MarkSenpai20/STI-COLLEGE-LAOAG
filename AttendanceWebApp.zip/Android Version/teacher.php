<?php require 'db_connect.php'; $ip = getServerIP(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Console</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="teacher-body">

<div class="main-layout">
    <!-- LEFT PANEL: CONTROLS -->
    <div class="control-panel">
        <h2>🎮 Teacher Controls</h2>
        
        <div class="input-group">
            <label>Current Class Name</label>
            <input type="text" id="className" placeholder="e.g. Physics 101" value="Physics 101">
        </div>

        <hr>

        <!-- REGISTER BUTTON -->
        <div class="control-box">
            <h3>📝 Registration Mode</h3>
            <p>Students enter Name & ID to create account.</p>
            <button id="btnReg" class="btn-start" onclick="setMode('REGISTER')">Start Register</button>
        </div>

        <!-- ATTENDANCE BUTTON -->
        <div class="control-box">
            <h3>✅ Attendance Mode</h3>
            <p>Students only enter ID. System verifies name.</p>
            <button id="btnAtt" class="btn-start" onclick="setMode('ATTENDANCE')">Start Sign In</button>
        </div>

        <button class="btn-stop" onclick="setMode('IDLE')">🛑 Stop Server (End Class)</button>

        <div class="ip-box">
            <small>Student Link:</small>
            <h1>http://<?php echo $ip; ?>/attendance</h1>
        </div>
    </div>

    <!-- RIGHT PANEL: LIVE VIEW -->
    <div class="live-panel">
        <div class="live-header">
            <h2 id="liveTitle">Waiting for command...</h2>
            <div class="count-badge" id="liveCount">0</div>
        </div>
        
        <div class="table-container">
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student Name</th>
                        <th>ID Number</th>
                        <th>Time/Status</th>
                    </tr>
                </thead>
                <tbody id="liveTableBody">
                    <!-- Rows injected by JS -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- BOTTOM PANEL: HISTORY -->
<div class="history-panel">
    <h3>📂 Class History</h3>
    <div class="history-grid" id="historyList">
        <!-- Folders loaded here -->
    </div>
</div>

<script>
let currentMode = 'IDLE';

// 1. Set Mode (Register/Attendance/Idle)
function setMode(mode) {
    const className = document.getElementById('className').value;
    if(!className && mode !== 'IDLE') { alert("Please enter a Class Name first!"); return; }

    // UI Updates
    document.querySelectorAll('.btn-start').forEach(b => b.classList.remove('active'));
    if(mode === 'REGISTER') document.getElementById('btnReg').classList.add('active');
    if(mode === 'ATTENDANCE') document.getElementById('btnAtt').classList.add('active');

    // Send to Server
    const formData = new FormData();
    formData.append('mode', mode);
    formData.append('class_name', className);

    fetch('db_connect.php?action=set_mode', { method: 'POST', body: formData })
    .then(res => res.json())
    .then(data => {
        currentMode = mode;
        document.getElementById('liveTitle').innerText = mode === 'IDLE' ? "Server Stopped" : "Live: " + mode + " - " + className;
        fetchLiveData(); // Immediate update
    });
}

// 2. Fetch Live List (Every 2 seconds)
function fetchLiveData() {
    if(currentMode === 'IDLE') return;

    fetch('db_connect.php?action=live_list')
    .then(res => res.json())
    .then(data => {
        const tbody = document.getElementById('liveTableBody');
        document.getElementById('liveCount').innerText = data.length;
        
        let html = '';
        // Reverse to show latest at top, but number them 1 to N based on total
        data.forEach((student, index) => {
            // Calculate row number (Total - Index for descending view)
            let rowNum = data.length - index; 
            let time = student.timestamp ? student.timestamp : "Registered";
            
            html += `
                <tr>
                    <td>${rowNum}</td>
                    <td><strong>${student.student_name}</strong></td>
                    <td>${student.student_id}</td>
                    <td>${time}</td>
                </tr>
            `;
        });
        tbody.innerHTML = html;
    });
}

// 3. Fetch History
function fetchHistory() {
    fetch('db_connect.php?action=get_history')
    .then(res => res.json())
    .then(data => {
        const container = document.getElementById('historyList');
        let html = '';
        data.forEach(item => {
            html += `
                <div class="folder">
                    <div class="folder-icon">📁</div>
                    <div class="folder-info">
                        <strong>${item.class_name}</strong>
                        <small>${item.session_date}</small>
                        <span>Total: ${item.count}</span>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;
    });
}

// Init
setInterval(fetchLiveData, 2000);
fetchHistory();
</script>
</body>
</html>

