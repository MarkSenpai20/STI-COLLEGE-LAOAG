<?php
header('Content-Type: application/json');
date_default_timezone_set('Asia/Manila'); // Set PH Time

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "school_db";
$conn = new mysqli($host, $user, $pass, $dbname);

$stateFile = 'server_state.json';

// --- HELPER: Get LAN IP ---
function getServerIP() {
    return gethostbyname(gethostname());
}

// --- HELPER: Manage State (Register Mode vs Attendance Mode) ---
function setServerState($mode, $className) {
    global $stateFile;
    $data = ["mode" => $mode, "class" => $className];
    file_put_contents($stateFile, json_encode($data));
}

function getServerState() {
    global $stateFile;
    if (!file_exists($stateFile)) return ["mode" => "IDLE", "class" => "None"];
    return json_decode(file_get_contents($stateFile), true);
}

// --- ACTION HANDLER ---
$action = $_GET['action'] ?? '';

// 1. TEACHER: Start a Mode
if ($action == 'set_mode') {
    $mode = $_POST['mode']; // 'REGISTER' or 'ATTENDANCE' or 'IDLE'
    $class = $_POST['class_name'];
    setServerState($mode, $class);
    echo json_encode(["status" => "success", "mode" => $mode]);
    exit;
}

// 2. STUDENT: Check what form to show
if ($action == 'get_status') {
    echo json_encode(getServerState());
    exit;
}

// 3. STUDENT: Submit Form
if ($action == 'submit' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $state = getServerState();
    $sid = $_POST['student_id'];
    $name = $_POST['student_name'] ?? ''; // Only used in Register mode
    $class = $state['class'];
    $date = date('Y-m-d');
    $time = date("h:i:s A");

    if ($state['mode'] == 'REGISTER') {
        // Save to Students Table (Identity)
        $check = $conn->query("SELECT id FROM students WHERE student_id = '$sid'");
        if ($check->num_rows > 0) {
            echo json_encode(["status" => "error", "message" => "ID Already Registered!"]);
        } else {
            $stmt = $conn->prepare("INSERT INTO students (student_name, student_id, class_name) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $sid, $class);
            $stmt->execute();
            echo json_encode(["status" => "success", "msg" => "Registered Successfully!"]);
        }
    } 
    elseif ($state['mode'] == 'ATTENDANCE') {
        // Validate against Students Table
        $studentQ = $conn->query("SELECT student_name FROM students WHERE student_id = '$sid'");
        
        if ($studentQ->num_rows == 0) {
            echo json_encode(["status" => "error", "message" => "ID Not Found! Please Register first."]);
        } else {
            $studentRow = $studentQ->fetch_assoc();
            $realName = $studentRow['student_name'];

            // Check if already present TODAY
            $logCheck = $conn->query("SELECT id FROM attendance_logs WHERE student_id = '$sid' AND session_date = '$date' AND class_name = '$class'");
            
            if ($logCheck->num_rows > 0) {
                echo json_encode(["status" => "error", "message" => "You are already marked present!"]);
            } else {
                $stmt = $conn->prepare("INSERT INTO attendance_logs (student_name, student_id, class_name, session_date, timestamp) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $realName, $sid, $class, $date, $time);
                $stmt->execute();
                echo json_encode(["status" => "success", "msg" => "Welcome, $realName!"]);
            }
        }
    }
    exit;
}

// 4. TEACHER: Get Live List
if ($action == 'live_list') {
    $state = getServerState();
    $class = $state['class'];
    $date = date('Y-m-d');
    $data = [];

    if ($state['mode'] == 'REGISTER') {
        // Show recently registered students
        $res = $conn->query("SELECT student_name, student_id FROM students WHERE class_name = '$class' ORDER BY id DESC");
        while($row = $res->fetch_assoc()) $data[] = $row;
    } 
    elseif ($state['mode'] == 'ATTENDANCE') {
        // Show today's logs
        $res = $conn->query("SELECT student_name, student_id, timestamp FROM attendance_logs WHERE class_name = '$class' AND session_date = '$date' ORDER BY id DESC");
        while($row = $res->fetch_assoc()) $data[] = $row;
    }
    echo json_encode($data);
    exit;
}

// 5. TEACHER: Get History (Grouped by Class/Date)
if ($action == 'get_history') {
    $res = $conn->query("SELECT class_name, session_date, COUNT(*) as count FROM attendance_logs GROUP BY class_name, session_date ORDER BY session_date DESC");
    $data = [];
    while($row = $res->fetch_assoc()) $data[] = $row;
    echo json_encode($data);
    exit;
}
?>


